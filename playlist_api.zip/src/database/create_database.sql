-- Cria o banco de dados se não existir
CREATE DATABASE IF NOT EXISTS playlist_db;

-- Usa o banco de dados
USE playlist_db;